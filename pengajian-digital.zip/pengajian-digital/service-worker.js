// =========================================================
// SERVICE WORKER: cache shell aplikasi untuk mode offline dasar.
// Data (Supabase) tetap butuh koneksi internet; yang di-cache
// hanya file statis (HTML/CSS/JS/ikon) agar aplikasi tetap
// terbuka saat offline dan bisa menampilkan data terakhir yang
// tersimpan di memori/localStorage.
// =========================================================
const CACHE_NAME = 'pengajian-digital-v1';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.json',
  './css/base.css',
  './css/theme.css',
  './css/components.css',
  './js/app.js',
  './js/config.js',
  './js/supabaseClient.js',
  './js/auth.js',
  './js/ui.js',
  './js/kegiatan.js',
  './js/absensi.js',
  './js/infaq.js',
  './js/dashboard.js',
  './js/organisasi.js',
  './js/kategori.js',
  './js/export.js',
  './js/whatsapp.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Jangan cache panggilan API Supabase — selalu ambil data terbaru dari jaringan
  if (url.hostname.includes('supabase.co')) {
    return; // biarkan browser menangani langsung (network)
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      return (
        cached ||
        fetch(event.request)
          .then((response) => {
            if (event.request.method === 'GET' && response.ok) {
              const clone = response.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
            }
            return response;
          })
          .catch(() => caches.match('./index.html'))
      );
    })
  );
});
