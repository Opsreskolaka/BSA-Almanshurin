// =========================================================
// MODUL EXPORT: PDF (jsPDF) & Excel (SheetJS)
// Library dimuat dari CDN di index.html sebagai window.jspdf & window.XLSX
// =========================================================
import { formatRupiah, formatJam, toast } from './ui.js';

function baris(no, a) {
  return [
    no,
    a.nama_lengkap,
    a.jenis_kelamin || '-',
    a.status_peserta || '-',
    a.dapukan || '-',
    `${formatJam(a.waktu_datang)} ${a.zona_waktu || ''}`,
    a.kehadiran,
    a.keterangan || '-',
    formatRupiah(a.nominal_infaq),
  ];
}

export function exportPDF(kegiatan, organisasi, absensiList) {
  try {
    // eslint-disable-next-line no-undef
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF({ orientation: 'landscape', unit: 'pt' });

    doc.setFontSize(14);
    doc.text(organisasi?.nama_organisasi || 'Organisasi', 40, 40);
    doc.setFontSize(10);
    doc.text(`${organisasi?.nama_masjid || ''}  •  ${organisasi?.nama_kelompok || ''}`, 40, 56);

    doc.setFontSize(12);
    doc.text(`Kegiatan: ${kegiatan.nama_kegiatan}`, 40, 80);
    doc.setFontSize(10);
    doc.text(`Tema: ${kegiatan.tema || '-'}`, 40, 96);
    doc.text(`Hari/Tanggal: ${kegiatan.hari || ''}, ${kegiatan.tanggal}`, 40, 112);
    doc.text(`Jam: ${kegiatan.jam_mulai} - ${kegiatan.jam_selesai || ''}`, 40, 128);
    doc.text(`Tempat: ${kegiatan.tempat || '-'}`, 300, 96);
    doc.text(`Pemateri: ${kegiatan.pemateri || '-'}`, 300, 112);

    const rows = absensiList.map((a, i) => baris(i + 1, a));
    // eslint-disable-next-line no-undef
    doc.autoTable({
      startY: 150,
      head: [['No', 'Nama', 'JK', 'Status', 'Dapukan', 'Waktu Datang', 'Kehadiran', 'Keterangan', 'Infaq']],
      body: rows,
      styles: { fontSize: 8 },
      headStyles: { fillColor: [15, 81, 50] },
    });

    const finalY = doc.lastAutoTable.finalY + 40;
    doc.text('MENGETAHUI', 600, finalY);
    doc.text('Penanggung Jawab', 600, finalY + 16);
    doc.text('_________________________', 600, finalY + 70);
    doc.text(kegiatan.penanggung_jawab || '-', 600, finalY + 86);
    doc.text(kegiatan.dapukan_penanggung_jawab || '-', 600, finalY + 100);

    doc.save(`Absensi-${kegiatan.nama_kegiatan}-${kegiatan.tanggal}.pdf`);
    toast('PDF berhasil diunduh.', 'success');
  } catch (err) {
    toast('Gagal membuat PDF: ' + err.message, 'error');
  }
}

export function exportExcel(kegiatan, absensiList) {
  try {
    const rows = absensiList.map((a, i) => ({
      No: i + 1,
      Nama: a.nama_lengkap,
      'Jenis Kelamin': a.jenis_kelamin,
      'Status Peserta': a.status_peserta,
      Dapukan: a.dapukan,
      'Waktu Datang': `${formatJam(a.waktu_datang)} ${a.zona_waktu || ''}`,
      Kehadiran: a.kehadiran,
      Keterangan: a.keterangan,
      'Nominal Infaq': Number(a.nominal_infaq || 0),
    }));
    // eslint-disable-next-line no-undef
    const ws = XLSX.utils.json_to_sheet(rows);
    // eslint-disable-next-line no-undef
    const wb = XLSX.utils.book_new();
    // eslint-disable-next-line no-undef
    XLSX.utils.book_append_sheet(wb, ws, 'Absensi');
    // eslint-disable-next-line no-undef
    XLSX.writeFile(wb, `Absensi-${kegiatan.nama_kegiatan}-${kegiatan.tanggal}.xlsx`);
    toast('Excel berhasil diunduh.', 'success');
  } catch (err) {
    toast('Gagal membuat Excel: ' + err.message, 'error');
  }
}

// Export Word: menghasilkan file .doc sederhana (format HTML yang dibuka Word)
// Untuk dokumen .docx murni dengan layout kompleks, gunakan alur PDF/Excel di atas
// atau proses lanjutan dengan pustaka docx khusus di sisi server.
export function exportWordSederhana(kegiatan, organisasi, absensiList) {
  try {
    const rows = absensiList
      .map((a, i) => `<tr>
        <td>${i + 1}</td><td>${a.nama_lengkap}</td><td>${a.jenis_kelamin || '-'}</td>
        <td>${a.status_peserta || '-'}</td><td>${a.dapukan || '-'}</td>
        <td>${formatJam(a.waktu_datang)} ${a.zona_waktu || ''}</td>
        <td>${a.kehadiran}</td><td>${a.keterangan || '-'}</td>
        <td>${formatRupiah(a.nominal_infaq)}</td>
      </tr>`)
      .join('');

    const html = `
      <html><head><meta charset="utf-8"></head><body>
      <h2>${organisasi?.nama_organisasi || ''}</h2>
      <p>${organisasi?.nama_masjid || ''} - ${organisasi?.nama_kelompok || ''}</p>
      <h3>${kegiatan.nama_kegiatan}</h3>
      <p>Tema: ${kegiatan.tema || '-'}<br/>
         Hari/Tanggal: ${kegiatan.hari || ''}, ${kegiatan.tanggal}<br/>
         Jam: ${kegiatan.jam_mulai} - ${kegiatan.jam_selesai || ''}<br/>
         Tempat: ${kegiatan.tempat || '-'}</p>
      <table border="1" cellspacing="0" cellpadding="4">
        <tr><th>No</th><th>Nama</th><th>JK</th><th>Status</th><th>Dapukan</th>
            <th>Waktu Datang</th><th>Kehadiran</th><th>Keterangan</th><th>Infaq</th></tr>
        ${rows}
      </table>
      </body></html>`;

    const blob = new Blob(['\ufeff', html], { type: 'application/msword' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Absensi-${kegiatan.nama_kegiatan}-${kegiatan.tanggal}.doc`;
    link.click();
    toast('Dokumen Word berhasil diunduh.', 'success');
  } catch (err) {
    toast('Gagal membuat dokumen Word: ' + err.message, 'error');
  }
}
