// =========================================================
// MODUL INFAQ: pencatatan & rekap
// =========================================================
import { supabase } from './supabaseClient.js';
import { toast, setLoading } from './ui.js';

export async function tambahInfaq(payload) {
  setLoading(true);
  try {
    const { data, error } = await supabase.from('infaq').insert(payload).select().single();
    if (error) throw error;
    toast('Infaq berhasil dicatat.', 'success');
    return data;
  } catch (err) {
    toast('Gagal mencatat infaq: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function listInfaq({ from = null, to = null, kegiatanId = null } = {}) {
  let query = supabase.from('infaq').select('*').order('created_at', { ascending: false });
  if (from) query = query.gte('created_at', from);
  if (to) query = query.lte('created_at', to);
  if (kegiatanId) query = query.eq('kegiatan_id', kegiatanId);
  const { data, error } = await query;
  if (error) {
    toast('Gagal memuat data infaq: ' + error.message, 'error');
    return [];
  }
  return data;
}

export async function totalInfaq({ from = null, to = null } = {}) {
  const data = await listInfaq({ from, to });
  return data.reduce((sum, row) => sum + Number(row.nominal || 0), 0);
}

export async function rekapPerPeriode(periode = 'harian') {
  const data = await listInfaq();
  const groups = {};
  data.forEach((row) => {
    const d = new Date(row.created_at);
    let key;
    if (periode === 'harian') key = d.toISOString().slice(0, 10);
    else if (periode === 'bulanan') key = d.toISOString().slice(0, 7);
    else key = String(d.getFullYear());
    groups[key] = (groups[key] || 0) + Number(row.nominal || 0);
  });
  return Object.entries(groups)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([label, total]) => ({ label, total }));
}

export function subscribeInfaq(callback) {
  return supabase
    .channel('infaq-realtime')
    .on('postgres_changes', { event: '*', schema: 'public', table: 'infaq' }, callback)
    .subscribe();
}
