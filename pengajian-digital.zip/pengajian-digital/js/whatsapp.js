// =========================================================
// MODUL WHATSAPP
// Menggunakan link "klik untuk chat" wa.me (tidak butuh API berbayar).
// Untuk pengiriman OTOMATIS massal ke banyak nomor/grup tanpa
// interaksi manual, dibutuhkan WhatsApp Business API resmi
// (mis. lewat provider seperti Fonnte/Wablas/Twilio) dan kredensial
// milik organisasi Anda sendiri - integrasikan di fungsi kirimViaProviderAPI().
// =========================================================
import { getLinkAbsensi } from './kegiatan.js';
import { formatTanggalIndo, formatJam } from './ui.js';

function normalisasiNomor(nomor) {
  let n = (nomor || '').replace(/\D/g, '');
  if (n.startsWith('0')) n = '62' + n.slice(1);
  if (!n.startsWith('62')) n = '62' + n;
  return n;
}

export function buatPesanLinkAbsensi(kegiatan) {
  const link = getLinkAbsensi(kegiatan);
  return `Assalamu'alaikum 🙏\nSilakan isi daftar hadir pengajian melalui link berikut atau scan QR Code terlampir.\n\nKegiatan: ${kegiatan.nama_kegiatan}\nTanggal: ${formatTanggalIndo(kegiatan.tanggal)} • ${formatJam(kegiatan.jam_mulai)} WIB\nTempat: ${kegiatan.tempat || '-'}\n\nLink: ${link}\n\nTerima kasih 🙏`;
}

export function bukaWhatsApp(nomor, pesan) {
  const n = normalisasiNomor(nomor);
  const url = `https://wa.me/${n}?text=${encodeURIComponent(pesan)}`;
  window.open(url, '_blank');
}

export function bukaWhatsAppTanpaNomor(pesan) {
  // Untuk "Semua Peserta" / "Grup WhatsApp": buka WA lalu user memilih tujuan sendiri
  const url = `https://wa.me/?text=${encodeURIComponent(pesan)}`;
  window.open(url, '_blank');
}

// Placeholder untuk integrasi API resmi (opsional, butuh kredensial sendiri)
export async function kirimViaProviderAPI(/* { apiKey, endpoint, nomor, pesan, mediaUrl } */) {
  throw new Error(
    'Integrasi WhatsApp Business API belum dikonfigurasi. ' +
    'Isi kredensial provider Anda (mis. Fonnte/Wablas) di fungsi ini untuk mengirim otomatis tanpa membuka WhatsApp.'
  );
}
