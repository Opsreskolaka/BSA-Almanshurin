// =========================================================
// Inisialisasi Supabase Client (dipakai oleh semua modul lain)
// =========================================================
import { SUPABASE_CONFIG } from './config.js';

// Library Supabase dimuat dari CDN di index.html sebagai window.supabase
export const supabase = window.supabase.createClient(
  SUPABASE_CONFIG.url,
  SUPABASE_CONFIG.anonKey,
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: false,
    },
    realtime: {
      params: { eventsPerSecond: 5 },
    },
  }
);

export function isConfigured() {
  return (
    !SUPABASE_CONFIG.url.includes('GANTI-DENGAN') &&
    !SUPABASE_CONFIG.anonKey.includes('GANTI-DENGAN')
  );
}
