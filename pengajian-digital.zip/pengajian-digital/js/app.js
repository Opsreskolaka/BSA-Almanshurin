// =========================================================
// APP.JS — Router & Render Views (SPA)
// =========================================================
import { isConfigured } from './supabaseClient.js';
import * as Auth from './auth.js';
import * as UI from './ui.js';
import * as Keg from './kegiatan.js';
import * as Abs from './absensi.js';
import * as Inf from './infaq.js';
import * as Dash from './dashboard.js';
import * as Org from './organisasi.js';
import * as Kat from './kategori.js';
import * as Exp from './export.js';
import * as WA from './whatsapp.js';

const appEl = document.getElementById('app');
let organisasi = null;

// ---------------------------------------------------------
// BOOTSTRAP
// ---------------------------------------------------------
async function bootstrap() {
  if (!isConfigured()) {
    renderConfigWarning();
    return;
  }
  await Auth.initAuth();
  organisasi = await Org.getOrganisasi();
  if (organisasi) Org.applyTheme(organisasi);

  window.addEventListener('hashchange', route);
  route();
}

function renderConfigWarning() {
  appEl.innerHTML = `
    <div class="login-screen">
      <div class="login-badge">⚠️</div>
      <h1>Konfigurasi Belum Lengkap</h1>
      <p class="tagline">Supabase belum terhubung</p>
      <div class="login-card">
        <p style="color:#fff;opacity:.85;font-size:13px;line-height:1.6">
          Buka <b>js/config.js</b> lalu isi <code>url</code> dan <code>anonKey</code>
          dari Supabase Dashboard → Project Settings → API. Setelah itu jalankan
          skrip SQL di folder <b>sql/</b> (01, 02, 03) pada Supabase SQL Editor.
        </p>
      </div>
    </div>`;
}

// ---------------------------------------------------------
// ROUTER
// ---------------------------------------------------------
const params = new URLSearchParams(window.location.search);
const publicEventId = params.get('event');
const publicToken = params.get('token');

async function route() {
  const hash = window.location.hash.replace('#', '') || 'dashboard';

  // Mode absensi publik (dari QR / link) — tidak perlu login
  if (publicEventId) {
    return renderAbsensiPublik(publicEventId, publicToken);
  }

  if (!Auth.isLoggedIn() && hash !== 'reset-password') {
    return renderLogin();
  }

  const [page, sub] = hash.split('/');
  switch (page) {
    case 'dashboard': return renderDashboard();
    case 'kegiatan': return sub ? renderDetailKegiatan(sub) : renderListKegiatan();
    case 'kegiatan-baru': return renderFormKegiatan();
    case 'infaq': return renderInfaq();
    case 'menu': return renderMenu();
    case 'pengaturan': return renderPengaturan();
    default: return renderDashboard();
  }
}

function shell(contentHtml, activeTab = '') {
  appEl.innerHTML = `
    ${brandHeader()}
    <div class="page">${contentHtml}</div>
    ${bottomNav(activeTab)}
  `;
}

function brandHeader() {
  const nama = organisasi?.nama_aplikasi || 'Daftar Hadir Pengajian';
  const orgName = organisasi?.nama_organisasi || 'Majelis';
  return `
    <div class="brand-header">
      <div class="logo">🕌</div>
      <div>
        <h2>${orgName}</h2>
        <p style="color:var(--color-text-muted)">${nama}</p>
      </div>
    </div>`;
}

function bottomNav(active) {
  const tabs = [
    { key: 'dashboard', icon: '🏠', label: 'Dashboard' },
    { key: 'kegiatan', icon: '📋', label: 'Kegiatan' },
    { key: 'fab', icon: '➕', label: '' },
    { key: 'infaq', icon: '💰', label: 'Infaq' },
    { key: 'menu', icon: '☰', label: 'Menu' },
  ];
  return `
    <div class="bottom-nav">
      ${tabs.map(t => t.key === 'fab'
        ? `<button class="fab" onclick="location.hash='kegiatan-baru'">➕</button>`
        : `<button class="${active === t.key ? 'active' : ''}" onclick="location.hash='${t.key}'">
             <span>${t.icon}</span><span>${t.label}</span>
           </button>`
      ).join('')}
    </div>`;
}

// ---------------------------------------------------------
// LOGIN
// ---------------------------------------------------------
function renderLogin() {
  appEl.innerHTML = `
    <div class="login-screen">
      <div class="login-badge">🕌</div>
      <h1>${organisasi?.nama_organisasi || 'Majelis Al-Ikhlas'}</h1>
      <p class="tagline">Sistem Daftar Hadir Pengajian</p>
      <div class="login-card">
        <div class="field">
          <label>Username atau Email</label>
          <input id="login-id" type="text" placeholder="admin atau admin@email.com" />
        </div>
        <div class="field field-icon-wrap">
          <label>Password</label>
          <input id="login-pw" type="password" placeholder="••••••••" />
          <button class="toggle-eye" id="toggle-pw" type="button">👁️</button>
        </div>
        <div class="remember-row">
          <label><input type="checkbox" id="remember" /> Ingat saya</label>
          <a href="#" class="link" id="lupa-pw">Lupa password?</a>
        </div>
        <button class="btn btn-primary" id="btn-login">Login</button>
        <div class="login-divider">atau</div>
        <button class="btn btn-ghost" id="btn-google">Login dengan Google</button>
      </div>
    </div>`;

  document.getElementById('toggle-pw').onclick = () => {
    const pw = document.getElementById('login-pw');
    pw.type = pw.type === 'password' ? 'text' : 'password';
  };
  document.getElementById('btn-login').onclick = async () => {
    const id = document.getElementById('login-id').value.trim();
    const pw = document.getElementById('login-pw').value;
    const remember = document.getElementById('remember').checked;
    if (!id || !pw) return UI.toast('Isi username/email dan password.', 'error');
    try {
      await Auth.login(id, pw, remember);
      route();
    } catch (_) { /* toast sudah ditampilkan */ }
  };
  document.getElementById('btn-google').onclick = () => Auth.loginWithGoogle();
  document.getElementById('lupa-pw').onclick = async (e) => {
    e.preventDefault();
    const email = prompt('Masukkan email Anda untuk reset password:');
    if (email) await Auth.resetPassword(email);
  };
}

// ---------------------------------------------------------
// DASHBOARD
// ---------------------------------------------------------
async function renderDashboard() {
  shell(`<div>${UI.skeletonCards(3)}</div>`, 'dashboard');
  const ringkasan = await Dash.getRingkasan();
  const grafik = await Dash.getGrafikKehadiran(7);

  const content = `
    <p>Assalamu'alaikum 👋<br><b>Selamat datang kembali, ${Auth.currentProfile?.nama_lengkap || ''}</b></p>
    <div class="stat-grid">
      <div class="stat-box"><div class="num">${ringkasan.totalKegiatan}</div><div class="label">Kegiatan</div></div>
      <div class="stat-box"><div class="num">${ringkasan.totalPeserta}</div><div class="label">Peserta</div></div>
      <div class="stat-box"><div class="num">${ringkasan.totalHadir}</div><div class="label">Hadir</div></div>
      <div class="stat-box"><div class="num">${ringkasan.totalIzin}</div><div class="label">Izin</div></div>
      <div class="stat-box"><div class="num">${ringkasan.totalSakit}</div><div class="label">Sakit</div></div>
      <div class="stat-box"><div class="num">${ringkasan.totalAlfa}</div><div class="label">Alfa</div></div>
    </div>
    <div class="card">
      <p style="margin-bottom:4px">Total Infaq</p>
      <h2 style="color:var(--color-primary)">${UI.formatRupiah(ringkasan.totalInfaq)}</h2>
    </div>
    <div class="section-title"><h3>Grafik Kehadiran (7 Hari Terakhir)</h3></div>
    <div class="card"><canvas id="chart-kehadiran" height="160"></canvas></div>
  `;
  document.querySelector('.page').innerHTML = content;
  Dash.renderChartKehadiran(document.getElementById('chart-kehadiran'), grafik.labels, grafik.values);

  Dash.subscribeDashboard(() => renderDashboard());
}

// ---------------------------------------------------------
// LIST KEGIATAN
// ---------------------------------------------------------
async function renderListKegiatan(status = 'semua', search = '') {
  shell(`
    <div class="search-bar">
      🔍 <input id="cari-kegiatan" placeholder="Cari kegiatan..." value="${search}" />
    </div>
    <div class="chip-group" id="filter-status">
      ${['semua', 'aktif', 'selesai', 'draft'].map(s =>
        `<button class="chip ${s === status ? 'active' : ''}" data-status="${s}">${s[0].toUpperCase() + s.slice(1)}</button>`
      ).join('')}
    </div>
    <div id="list-kegiatan">${UI.skeletonCards(4)}</div>
  `, 'kegiatan');

  const list = await Keg.listKegiatan({ status, search });
  document.getElementById('list-kegiatan').innerHTML = list.length
    ? list.map(kegiatanCardHtml).join('')
    : `<p style="text-align:center;padding:30px 0">Belum ada kegiatan.</p>`;

  document.querySelectorAll('#filter-status .chip').forEach(chip => {
    chip.onclick = () => renderListKegiatan(chip.dataset.status, search);
  });
  document.getElementById('cari-kegiatan').oninput = (e) => renderListKegiatan(status, e.target.value);
  document.querySelectorAll('.kegiatan-card').forEach(card => {
    card.onclick = () => { location.hash = `kegiatan/${card.dataset.id}`; };
  });
}

function kegiatanCardHtml(k) {
  const badgeClass = { aktif: 'badge-aktif', selesai: 'badge-selesai', draft: 'badge-draft' }[k.status];
  return `
    <div class="card kegiatan-card" data-id="${k.id}" style="cursor:pointer">
      <div class="list-item" style="border:none;padding:0">
        <div class="avatar">🕌</div>
        <div style="flex:1">
          <div class="title">${k.nama_kegiatan}</div>
          <div class="sub">${k.hari || ''}, ${UI.formatTanggalIndo(k.tanggal)} • ${UI.formatJam(k.jam_mulai)} WIB</div>
          <div class="sub">${k.tempat || '-'}</div>
        </div>
        <span class="badge ${badgeClass}">${k.status}</span>
      </div>
    </div>`;
}

// ---------------------------------------------------------
// FORM TAMBAH / EDIT KEGIATAN
// ---------------------------------------------------------
async function renderFormKegiatan(existing = null) {
  const kategoriList = await Kat.listKategori();
  shell(`
    <div class="card">
      <h3>${existing ? 'Edit Kegiatan' : 'Tambah Kegiatan'}</h3>
      <form id="form-kegiatan">
        <div class="field"><label>Nama Kegiatan</label><input name="nama_kegiatan" required value="${existing?.nama_kegiatan || ''}" /></div>
        <div class="field"><label>Kategori</label>
          <select name="kategori_id">
            ${kategoriList.map(k => `<option value="${k.id}" ${existing?.kategori_id === k.id ? 'selected' : ''}>${k.nama_kategori}</option>`).join('')}
          </select>
        </div>
        <div class="field"><label>Tema</label><input name="tema" value="${existing?.tema || ''}" /></div>
        <div class="field"><label>Hari</label><input name="hari" value="${existing?.hari || ''}" /></div>
        <div class="field"><label>Tanggal</label><input type="date" name="tanggal" required value="${existing?.tanggal || ''}" /></div>
        <div class="field"><label>Jam Mulai</label><input type="time" name="jam_mulai" required value="${existing?.jam_mulai || ''}" /></div>
        <div class="field"><label>Jam Selesai</label><input type="time" name="jam_selesai" value="${existing?.jam_selesai || ''}" /></div>
        <div class="field"><label>Tempat</label><input name="tempat" value="${existing?.tempat || ''}" /></div>
        <div class="field"><label>Pemateri</label><input name="pemateri" value="${existing?.pemateri || ''}" /></div>
        <div class="field"><label>Penanggung Jawab</label><input name="penanggung_jawab" value="${existing?.penanggung_jawab || ''}" /></div>
        <div class="field"><label>Dapukan Penanggung Jawab</label><input name="dapukan_penanggung_jawab" value="${existing?.dapukan_penanggung_jawab || ''}" /></div>
        <div class="field"><label>Nomor WhatsApp PJ</label><input name="nomor_whatsapp_pj" value="${existing?.nomor_whatsapp_pj || ''}" /></div>
        <div class="field"><label>Catatan</label><textarea name="catatan">${existing?.catatan || ''}</textarea></div>
        <div class="field"><label>Status</label>
          <select name="status">
            ${['draft','aktif','selesai'].map(s => `<option value="${s}" ${existing?.status === s ? 'selected' : ''}>${s}</option>`).join('')}
          </select>
        </div>
        <button class="btn btn-primary" type="submit">Simpan Kegiatan</button>
      </form>
    </div>
  `, 'kegiatan');

  document.getElementById('form-kegiatan').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    payload.dibuat_oleh = Auth.currentUser?.id || null;
    try {
      const saved = existing
        ? await Keg.updateKegiatan(existing.id, payload)
        : await Keg.createKegiatan(payload);
      location.hash = `kegiatan/${saved.id}`;
    } catch (_) { /* toast sudah ditampilkan */ }
  };
}

// ---------------------------------------------------------
// DETAIL KEGIATAN: QR, link, daftar hadir, export, WA
// ---------------------------------------------------------
async function renderDetailKegiatan(id) {
  shell(`<div>${UI.skeletonCards(3)}</div>`, 'kegiatan');
  const kegiatan = await Keg.getKegiatanById(id);
  if (!kegiatan) { location.hash = 'kegiatan'; return; }
  const link = Keg.getLinkAbsensi(kegiatan);

  const content = `
    <div class="card">
      <h3>${kegiatan.nama_kegiatan}</h3>
      <p>${kegiatan.hari || ''}, ${UI.formatTanggalIndo(kegiatan.tanggal)} • ${UI.formatJam(kegiatan.jam_mulai)} WIB</p>
      <p>${kegiatan.tempat || '-'}</p>
      <div class="btn-row">
        <button class="btn btn-outline btn-sm" id="btn-edit">✏️ Edit</button>
        <button class="btn btn-danger btn-sm" id="btn-hapus">🗑️ Hapus</button>
      </div>
    </div>

    <div class="section-title"><h3>QR Code & Link Absensi</h3></div>
    <div class="card" style="text-align:center">
      <p style="word-break:break-all;font-size:12px">${link}</p>
      <button class="btn btn-ghost btn-sm" id="btn-copy">📋 Salin Link</button>
      <div class="qr-box"><div id="qr-container"></div></div>
      <div class="btn-row">
        <button class="btn btn-outline" id="btn-dl-png">⬇️ PNG</button>
        <button class="btn btn-outline" id="btn-dl-svg">⬇️ SVG</button>
      </div>
    </div>

    <div class="section-title"><h3>Kirim ke Peserta</h3></div>
    <div class="card">
      <button class="btn btn-primary" id="btn-wa-semua">💬 Kirim via WhatsApp</button>
    </div>

    <div class="section-title"><h3>Daftar Hadir (Realtime)</h3><span id="jumlah-hadir"></span></div>
    <div class="card" id="daftar-hadir">${UI.skeletonCards(2)}</div>

    <div class="section-title"><h3>Export Laporan</h3></div>
    <div class="card">
      <div class="btn-row">
        <button class="btn btn-outline btn-sm" id="btn-pdf">📄 PDF</button>
        <button class="btn btn-outline btn-sm" id="btn-word">📝 Word</button>
        <button class="btn btn-outline btn-sm" id="btn-excel">📊 Excel</button>
      </div>
    </div>
  `;
  document.querySelector('.page').innerHTML = content;

  Keg.renderQRCode(document.getElementById('qr-container'), link, 220);
  document.getElementById('btn-copy').onclick = () => {
    navigator.clipboard.writeText(link);
    UI.toast('Link disalin ke clipboard.', 'success');
  };
  document.getElementById('btn-dl-png').onclick = () =>
    Keg.downloadQRasPNG(document.getElementById('qr-container'), `QR-${kegiatan.nama_kegiatan}.png`);
  document.getElementById('btn-dl-svg').onclick = () =>
    Keg.downloadQRasSVG(link, `QR-${kegiatan.nama_kegiatan}.svg`);

  document.getElementById('btn-edit').onclick = () => renderFormKegiatan(kegiatan);
  document.getElementById('btn-hapus').onclick = async () => {
    if (await UI.confirmDialog('Yakin ingin menghapus kegiatan ini beserta seluruh data absensinya?')) {
      await Keg.deleteKegiatan(kegiatan.id);
      location.hash = 'kegiatan';
    }
  };
  document.getElementById('btn-wa-semua').onclick = () =>
    WA.bukaWhatsAppTanpaNomor(WA.buatPesanLinkAbsensi(kegiatan));

  async function refreshDaftarHadir() {
    const list = await Abs.listAbsensiByKegiatan(kegiatan.id);
    document.getElementById('jumlah-hadir').textContent = `${list.length} peserta`;
    document.getElementById('daftar-hadir').innerHTML = list.length
      ? list.map(a => `
          <div class="list-item">
            <div class="avatar">${a.jenis_kelamin === 'Wanita' ? '👩' : '👨'}</div>
            <div style="flex:1">
              <div class="title">${a.nama_lengkap}</div>
              <div class="sub">${UI.formatJam(a.waktu_datang)} ${a.zona_waktu} • ${a.dapukan || '-'}</div>
            </div>
            <span class="badge badge-aktif">${a.kehadiran}</span>
          </div>`).join('')
      : `<p style="text-align:center;padding:16px 0">Belum ada yang mengisi absensi.</p>`;

    document.getElementById('btn-pdf').onclick = () => Exp.exportPDF(kegiatan, organisasi, list);
    document.getElementById('btn-word').onclick = () => Exp.exportWordSederhana(kegiatan, organisasi, list);
    document.getElementById('btn-excel').onclick = () => Exp.exportExcel(kegiatan, list);
  }
  await refreshDaftarHadir();
  Abs.subscribeAbsensi(kegiatan.id, refreshDaftarHadir);
}

// ---------------------------------------------------------
// ABSENSI PUBLIK (dibuka via scan QR / link, tanpa login)
// ---------------------------------------------------------
async function renderAbsensiPublik(eventId) {
  const kegiatan = await Keg.getKegiatanById(eventId);
  if (!kegiatan) {
    appEl.innerHTML = `<div class="page"><div class="card">Kegiatan tidak ditemukan atau link tidak valid.</div></div>`;
    return;
  }

  appEl.innerHTML = `
    <div class="page">
      <div class="card">
        <div class="badge badge-aktif">${kegiatan.status}</div>
        <h3>${kegiatan.nama_kegiatan}</h3>
        <p>${kegiatan.hari || ''}, ${UI.formatTanggalIndo(kegiatan.tanggal)} • ${UI.formatJam(kegiatan.jam_mulai)} WIB</p>
        <p>${kegiatan.tempat || '-'}</p>
      </div>
      <div class="card">
        <h3>Absensi Peserta</h3>
        <form id="form-absensi">
          <div class="field"><label>Nama Lengkap *</label><input name="nama_lengkap" required /></div>
          <div class="field"><label>Jenis Kelamin *</label>
            <div class="radio-group">
              <label class="chip"><input type="radio" name="jenis_kelamin" value="Pria" required style="margin-right:6px"/>Pria</label>
              <label class="chip"><input type="radio" name="jenis_kelamin" value="Wanita" style="margin-right:6px"/>Wanita</label>
            </div>
          </div>
          <div class="field"><label>Status Peserta</label><input name="status_peserta" placeholder="mis. Muda-Mudi" /></div>
          <div class="field"><label>Dapukan</label><input name="dapukan" /></div>
          <div class="field"><label>Nomor WhatsApp</label><input name="nomor_whatsapp" type="tel" /></div>
          <div class="field"><label>Alamat</label><input name="alamat" /></div>
          <div class="field"><label>Zona Waktu</label>
            <select name="zona_waktu"><option>WIB</option><option>WITA</option><option>WIT</option></select>
          </div>
          <div class="field"><label>Kehadiran *</label>
            <select name="kehadiran" required>
              <option>Hadir</option><option>Izin/Berhalangan</option><option>Sakit</option><option>Alfa</option>
            </select>
          </div>
          <div class="field"><label>Keterangan</label><textarea name="keterangan"></textarea></div>
          <div class="field"><label>Nominal Infaq (Opsional)</label><input name="nominal_infaq" type="number" min="0" placeholder="0" /></div>
          <div class="field">
            <label>Tanda Tangan *</label>
            <div class="signature-wrap"><canvas id="ttd-canvas"></canvas></div>
            <button type="button" class="btn btn-ghost btn-sm" style="margin-top:8px" id="btn-reset-ttd">Reset</button>
          </div>
          <button class="btn btn-primary" type="submit">Simpan Absensi</button>
        </form>
      </div>
    </div>`;

  const canvas = document.getElementById('ttd-canvas');
  const pad = new Abs.SignaturePad(canvas);
  document.getElementById('btn-reset-ttd').onclick = () => pad.clear();

  document.getElementById('form-absensi').onsubmit = async (e) => {
    e.preventDefault();
    if (pad.isEmpty()) return UI.toast('Mohon bubuhkan tanda tangan.', 'error');
    const fd = new FormData(e.target);
    const data = Object.fromEntries(fd.entries());
    try {
      await Abs.simpanAbsensi(data, pad, kegiatan.id);
      appEl.innerHTML = `
        <div class="page" style="text-align:center;padding-top:60px">
          <div style="font-size:60px">✅</div>
          <h2>Absensi Berhasil!</h2>
          <p>Terima kasih, ${data.nama_lengkap}. Data Anda telah tersimpan.</p>
        </div>`;
    } catch (_) { /* toast sudah ditampilkan */ }
  };
}

// ---------------------------------------------------------
// INFAQ
// ---------------------------------------------------------
async function renderInfaq() {
  shell(`<div>${UI.skeletonCards(3)}</div>`, 'infaq');
  const total = await Inf.totalInfaq();
  const list = await Inf.listInfaq();

  const content = `
    <div class="card">
      <p>Total Infaq</p>
      <h2 style="color:var(--color-primary)">${UI.formatRupiah(total)}</h2>
    </div>
    <div class="section-title"><h3>Tambah Infaq</h3></div>
    <div class="card">
      <form id="form-infaq">
        <div class="field"><label>Nama Peserta</label><input name="nama_peserta" required /></div>
        <div class="field"><label>Nominal</label><input name="nominal" type="number" min="0" required /></div>
        <div class="field"><label>Metode Pembayaran</label>
          <select name="metode_pembayaran"><option>Tunai</option><option>Transfer</option><option>QRIS</option><option>Lainnya</option></select>
        </div>
        <div class="field"><label>Keterangan</label><input name="keterangan" /></div>
        <button class="btn btn-primary" type="submit">Simpan</button>
      </form>
    </div>
    <div class="section-title"><h3>Riwayat Infaq</h3></div>
    <div class="card" id="list-infaq">
      ${list.length ? list.map(i => `
        <div class="list-item">
          <div class="avatar">💰</div>
          <div style="flex:1">
            <div class="title">${i.nama_peserta}</div>
            <div class="sub">${UI.formatTanggalIndo(i.created_at)} • ${i.metode_pembayaran || '-'}</div>
          </div>
          <b>${UI.formatRupiah(i.nominal)}</b>
        </div>`).join('') : '<p style="text-align:center;padding:16px 0">Belum ada data infaq.</p>'}
    </div>
  `;
  document.querySelector('.page').innerHTML = content;

  document.getElementById('form-infaq').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    payload.nominal = Number(payload.nominal);
    try {
      await Inf.tambahInfaq(payload);
      renderInfaq();
    } catch (_) { /* toast sudah ditampilkan */ }
  };
}

// ---------------------------------------------------------
// MENU (pengaturan, kategori, logout, dll)
// ---------------------------------------------------------
function renderMenu() {
  shell(`
    <div class="card">
      <div class="list-item"><div class="avatar">👤</div>
        <div style="flex:1">
          <div class="title">${Auth.currentProfile?.nama_lengkap || '-'}</div>
          <div class="sub">${Auth.currentProfile?.role || '-'}</div>
        </div>
      </div>
    </div>
    <div class="card">
      <button class="btn btn-ghost" style="justify-content:flex-start" onclick="location.hash='pengaturan'">⚙️ Identitas Organisasi & Kategori</button>
    </div>
    <div class="card">
      <button class="btn btn-ghost" style="justify-content:flex-start" id="btn-dark">🌙 Mode Gelap / Terang</button>
    </div>
    <div class="card">
      <button class="btn btn-danger" id="btn-logout">🚪 Logout</button>
    </div>
  `, 'menu');

  document.getElementById('btn-logout').onclick = async () => {
    if (await UI.confirmDialog('Yakin ingin logout?')) {
      await Auth.logout();
      location.hash = 'dashboard';
      route();
    }
  };
  document.getElementById('btn-dark').onclick = () => {
    const html = document.documentElement;
    const dark = html.getAttribute('data-theme') === 'dark';
    html.setAttribute('data-theme', dark ? 'light' : 'dark');
    localStorage.setItem('theme', dark ? 'light' : 'dark');
  };
}

// ---------------------------------------------------------
// PENGATURAN: identitas organisasi + kategori
// ---------------------------------------------------------
async function renderPengaturan() {
  shell(`<div>${UI.skeletonCards(2)}</div>`, 'menu');
  const kategoriList = await Kat.listKategori();

  const content = `
    <div class="section-title"><h3>Identitas Organisasi</h3></div>
    <div class="card">
      <form id="form-org">
        <div class="field"><label>Nama Organisasi</label><input name="nama_organisasi" value="${organisasi?.nama_organisasi || ''}" /></div>
        <div class="field"><label>Nama Masjid</label><input name="nama_masjid" value="${organisasi?.nama_masjid || ''}" /></div>
        <div class="field"><label>Nama Kelompok</label><input name="nama_kelompok" value="${organisasi?.nama_kelompok || ''}" /></div>
        <div class="field"><label>Nama Aplikasi</label><input name="nama_aplikasi" value="${organisasi?.nama_aplikasi || ''}" /></div>
        <div class="field"><label>Footer</label><input name="footer_text" value="${organisasi?.footer_text || ''}" /></div>
        <div class="field"><label>Warna Primer</label><input type="color" name="warna_primer" value="${organisasi?.warna_primer || '#0F5132'}" /></div>
        <div class="field"><label>Warna Aksen</label><input type="color" name="warna_aksen" value="${organisasi?.warna_aksen || '#D4AF37'}" /></div>
        <div class="field"><label>Unggah Logo</label><input type="file" id="upload-logo" accept="image/*" /></div>
        <div class="field"><label>Unggah Stempel</label><input type="file" id="upload-stempel" accept="image/*" /></div>
        <button class="btn btn-primary" type="submit">Simpan Perubahan</button>
      </form>
    </div>

    <div class="section-title"><h3>Master Kategori</h3></div>
    <div class="card">
      <div class="btn-row" style="margin-bottom:12px">
        <input id="kategori-baru" placeholder="Nama kategori baru" style="flex:1;padding:10px;border-radius:10px;border:1.5px solid var(--color-border)" />
        <button class="btn btn-primary btn-sm" id="btn-tambah-kategori">Tambah</button>
      </div>
      <div id="list-kategori">
        ${kategoriList.map(k => `
          <div class="list-item">
            <div style="flex:1">${k.nama_kategori}</div>
            <button class="btn btn-ghost btn-sm" data-edit="${k.id}" data-nama="${k.nama_kategori}">✏️</button>
            <button class="btn btn-ghost btn-sm" data-hapus="${k.id}">🗑️</button>
          </div>`).join('')}
      </div>
    </div>
  `;
  document.querySelector('.page').innerHTML = content;

  let logoFile = null, stempelFile = null;
  document.getElementById('upload-logo').onchange = (e) => { logoFile = e.target.files[0]; };
  document.getElementById('upload-stempel').onchange = (e) => { stempelFile = e.target.files[0]; };

  document.getElementById('form-org').onsubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData(e.target);
    const payload = Object.fromEntries(fd.entries());
    try {
      if (logoFile) payload.logo_url = await Org.uploadGambarOrganisasi(logoFile, 'logo');
      if (stempelFile) payload.stempel_url = await Org.uploadGambarOrganisasi(stempelFile, 'stempel');
      organisasi = await Org.updateOrganisasi(organisasi.id, payload);
    } catch (_) { /* toast sudah ditampilkan */ }
  };

  document.getElementById('btn-tambah-kategori').onclick = async () => {
    const nama = document.getElementById('kategori-baru').value.trim();
    if (!nama) return;
    await Kat.tambahKategori(nama);
    renderPengaturan();
  };
  document.querySelectorAll('[data-hapus]').forEach(btn => {
    btn.onclick = async () => {
      if (await UI.confirmDialog('Hapus kategori ini?')) {
        await Kat.hapusKategori(btn.dataset.hapus);
        renderPengaturan();
      }
    };
  });
  document.querySelectorAll('[data-edit]').forEach(btn => {
    btn.onclick = async () => {
      const nama = prompt('Nama kategori baru:', btn.dataset.nama);
      if (nama) { await Kat.editKategori(btn.dataset.edit, nama); renderPengaturan(); }
    };
  });
}

// ---------------------------------------------------------
bootstrap();
