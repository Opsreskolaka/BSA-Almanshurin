// =========================================================
// MODUL DASHBOARD: statistik ringkas + grafik (Chart.js dari CDN)
// =========================================================
import { supabase } from './supabaseClient.js';
import { toast } from './ui.js';

export async function getRingkasan() {
  const [{ count: totalKegiatan }, { count: totalPeserta }, absensiRows, infaqRows] = await Promise.all([
    supabase.from('kegiatan').select('*', { count: 'exact', head: true }),
    supabase.from('peserta').select('*', { count: 'exact', head: true }),
    supabase.from('absensi').select('kehadiran'),
    supabase.from('infaq').select('nominal'),
  ]);

  const hitung = (status) => (absensiRows.data || []).filter((a) => a.kehadiran === status).length;

  return {
    totalKegiatan: totalKegiatan || 0,
    totalPeserta: totalPeserta || (absensiRows.data ? absensiRows.data.length : 0),
    totalHadir: hitung('Hadir'),
    totalIzin: hitung('Izin/Berhalangan'),
    totalSakit: hitung('Sakit'),
    totalAlfa: hitung('Alfa'),
    totalInfaq: (infaqRows.data || []).reduce((s, r) => s + Number(r.nominal || 0), 0),
  };
}

export async function getGrafikKehadiran(hariTerakhir = 7) {
  const sejak = new Date();
  sejak.setDate(sejak.getDate() - hariTerakhir);
  const { data, error } = await supabase
    .from('absensi')
    .select('waktu_datang')
    .eq('kehadiran', 'Hadir')
    .gte('waktu_datang', sejak.toISOString());
  if (error) {
    toast('Gagal memuat grafik kehadiran: ' + error.message, 'error');
    return { labels: [], values: [] };
  }
  const perHari = {};
  data.forEach((row) => {
    const key = new Date(row.waktu_datang).toLocaleDateString('id-ID', { weekday: 'short' });
    perHari[key] = (perHari[key] || 0) + 1;
  });
  return { labels: Object.keys(perHari), values: Object.values(perHari) };
}

let chartInstance = null;
export function renderChartKehadiran(canvasEl, labels, values) {
  if (chartInstance) chartInstance.destroy();
  // eslint-disable-next-line no-undef
  chartInstance = new Chart(canvasEl, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Kehadiran',
        data: values,
        borderColor: '#0F5132',
        backgroundColor: 'rgba(15,81,50,0.15)',
        tension: 0.35,
        fill: true,
        pointBackgroundColor: '#D4AF37',
      }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });
}

export function subscribeDashboard(callback) {
  const channel = supabase.channel('dashboard-realtime');
  ['absensi', 'infaq', 'kegiatan'].forEach((table) => {
    channel.on('postgres_changes', { event: '*', schema: 'public', table }, callback);
  });
  return channel.subscribe();
}
