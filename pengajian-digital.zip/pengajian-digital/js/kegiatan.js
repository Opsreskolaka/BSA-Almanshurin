// =========================================================
// MODUL KEGIATAN: CRUD + generate link & QR absensi
// =========================================================
import { supabase } from './supabaseClient.js';
import { APP_BASE_URL } from './config.js';
import { toast, setLoading } from './ui.js';

export async function listKegiatan({ status = null, search = null } = {}) {
  let query = supabase.from('kegiatan').select('*, kategori(nama_kategori)').order('tanggal', { ascending: false });
  if (status && status !== 'semua') query = query.eq('status', status);
  if (search) query = query.ilike('nama_kegiatan', `%${search}%`);
  const { data, error } = await query;
  if (error) {
    toast('Gagal memuat daftar kegiatan: ' + error.message, 'error');
    return [];
  }
  return data;
}

export async function getKegiatanById(id) {
  const { data, error } = await supabase.from('kegiatan').select('*, kategori(nama_kategori)').eq('id', id).maybeSingle();
  if (error) {
    toast('Gagal memuat kegiatan: ' + error.message, 'error');
    return null;
  }
  return data;
}

export async function createKegiatan(payload) {
  setLoading(true);
  try {
    const { data, error } = await supabase.from('kegiatan').insert(payload).select().single();
    if (error) throw error;
    toast('Kegiatan berhasil dibuat.', 'success');
    return data;
  } catch (err) {
    toast('Gagal membuat kegiatan: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function updateKegiatan(id, payload) {
  setLoading(true);
  try {
    const { data, error } = await supabase.from('kegiatan').update(payload).eq('id', id).select().single();
    if (error) throw error;
    toast('Kegiatan berhasil diperbarui.', 'success');
    return data;
  } catch (err) {
    toast('Gagal memperbarui kegiatan: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function deleteKegiatan(id) {
  setLoading(true);
  try {
    const { error } = await supabase.from('kegiatan').delete().eq('id', id);
    if (error) throw error;
    toast('Kegiatan berhasil dihapus.', 'success');
  } catch (err) {
    toast('Gagal menghapus kegiatan: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

// Link absensi publik untuk sebuah kegiatan
export function getLinkAbsensi(kegiatan) {
  const url = new URL(APP_BASE_URL);
  url.searchParams.set('event', kegiatan.id);
  url.searchParams.set('token', kegiatan.token_absensi);
  return url.toString();
}

// Render QR code ke sebuah elemen canvas/div menggunakan library QRCode (CDN)
// Level koreksi error 'H' agar tetap terbaca walau dicetak & sedikit rusak.
export function renderQRCode(containerEl, text, sizePx = 320) {
  containerEl.innerHTML = '';
  // eslint-disable-next-line no-undef
  new QRCode(containerEl, {
    text,
    width: sizePx,
    height: sizePx,
    correctLevel: QRCode.CorrectLevel.H,
  });
}

export function downloadQRasPNG(containerEl, filename = 'qr-absensi.png') {
  const canvas = containerEl.querySelector('canvas');
  if (!canvas) return toast('QR belum siap, coba lagi.', 'error');
  const link = document.createElement('a');
  link.download = filename;
  link.href = canvas.toDataURL('image/png');
  link.click();
}

export function downloadQRasSVG(text, filename = 'qr-absensi.svg') {
  // Generate SVG terpisah menggunakan qrcode-svg jika tersedia,
  // fallback: instruksikan pakai PNG bila library SVG tidak dimuat.
  if (typeof QRCodeSVG === 'undefined') {
    toast('Format SVG tidak tersedia, silakan unduh PNG.', 'info');
    return;
  }
  // eslint-disable-next-line no-undef
  const qr = new QRCodeSVG({ content: text, padding: 2, width: 320, height: 320, ecl: 'H' });
  const svgString = qr.svg();
  const blob = new Blob([svgString], { type: 'image/svg+xml' });
  const link = document.createElement('a');
  link.download = filename;
  link.href = URL.createObjectURL(blob);
  link.click();
}
