// =========================================================
// MODUL IDENTITAS ORGANISASI
// =========================================================
import { supabase } from './supabaseClient.js';
import { STORAGE_BUCKETS } from './config.js';
import { toast, setLoading } from './ui.js';

export async function getOrganisasi() {
  const { data, error } = await supabase.from('organisasi').select('*').limit(1).maybeSingle();
  if (error) {
    toast('Gagal memuat identitas organisasi: ' + error.message, 'error');
    return null;
  }
  return data;
}

export async function updateOrganisasi(id, payload) {
  setLoading(true);
  try {
    const { data, error } = await supabase.from('organisasi').update(payload).eq('id', id).select().single();
    if (error) throw error;
    toast('Identitas organisasi berhasil diperbarui.', 'success');
    applyTheme(data);
    return data;
  } catch (err) {
    toast('Gagal menyimpan: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function uploadGambarOrganisasi(file, jenis /* 'logo' | 'stempel' */) {
  const bucket = jenis === 'stempel' ? STORAGE_BUCKETS.stempel : STORAGE_BUCKETS.logo;
  const filename = `${Date.now()}-${file.name}`;
  const { error } = await supabase.storage.from(bucket).upload(filename, file, { upsert: true });
  if (error) throw error;
  const { data } = supabase.storage.from(bucket).getPublicUrl(filename);
  return data.publicUrl;
}

export function applyTheme(org) {
  if (!org) return;
  document.documentElement.style.setProperty('--color-primary', org.warna_primer || '#0F5132');
  document.documentElement.style.setProperty('--color-accent', org.warna_aksen || '#D4AF37');
  document.title = org.nama_aplikasi || 'Daftar Hadir Pengajian Digital';
}
