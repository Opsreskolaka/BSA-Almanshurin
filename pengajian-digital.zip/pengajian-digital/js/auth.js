// =========================================================
// AUTH: Login, Logout, Reset Password, Session, Role
// =========================================================
import { supabase } from './supabaseClient.js';
import { toast, setLoading } from './ui.js';

export let currentUser = null;   // { id, email, ... } dari auth.users
export let currentProfile = null; // baris dari public.users (berisi role)

export async function initAuth() {
  const { data: { session } } = await supabase.auth.getSession();
  if (session) {
    await loadProfile(session.user);
  }
  supabase.auth.onAuthStateChange(async (event, session) => {
    if (event === 'SIGNED_IN' && session) {
      await loadProfile(session.user);
    }
    if (event === 'SIGNED_OUT') {
      currentUser = null;
      currentProfile = null;
    }
  });
  return currentProfile;
}

async function loadProfile(user) {
  currentUser = user;
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', user.id)
    .maybeSingle();
  if (!error && data) {
    currentProfile = data;
  } else {
    // Profil belum ada di tabel public.users (mis. baru dibuat via dashboard)
    currentProfile = { id: user.id, email: user.email, role: 'peserta', nama_lengkap: user.email };
  }
  return currentProfile;
}

export async function login(identifier, password, rememberMe) {
  setLoading(true);
  try {
    // identifier bisa email atau username -> cari email jika bukan format email
    let email = identifier;
    if (!identifier.includes('@')) {
      const { data } = await supabase
        .from('users')
        .select('email')
        .eq('username', identifier)
        .maybeSingle();
      if (data?.email) email = data.email;
    }

    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;

    localStorage.setItem('remember_login', rememberMe ? '1' : '0');
    await loadProfile(data.user);
    toast('Login berhasil. Selamat datang!', 'success');
    return currentProfile;
  } catch (err) {
    toast(err.message || 'Login gagal. Periksa kembali username/password.', 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function loginWithGoogle() {
  const { error } = await supabase.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: window.location.href },
  });
  if (error) toast(error.message, 'error');
}

export async function logout() {
  await supabase.auth.signOut();
  currentUser = null;
  currentProfile = null;
  toast('Anda telah keluar.', 'info');
}

export async function resetPassword(email) {
  setLoading(true);
  try {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: window.location.href,
    });
    if (error) throw error;
    toast('Link reset password telah dikirim ke email Anda.', 'success');
  } catch (err) {
    toast(err.message || 'Gagal mengirim link reset password.', 'error');
  } finally {
    setLoading(false);
  }
}

export function hasRole(...roles) {
  return currentProfile && roles.includes(currentProfile.role);
}

export function isLoggedIn() {
  return !!currentUser;
}
