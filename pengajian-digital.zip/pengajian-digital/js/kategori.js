// =========================================================
// MODUL KATEGORI PENGAJIAN (CRUD)
// =========================================================
import { supabase } from './supabaseClient.js';
import { toast, setLoading } from './ui.js';

export async function listKategori() {
  const { data, error } = await supabase.from('kategori').select('*').order('urutan', { ascending: true });
  if (error) {
    toast('Gagal memuat kategori: ' + error.message, 'error');
    return [];
  }
  return data;
}

export async function tambahKategori(nama_kategori) {
  setLoading(true);
  try {
    const { data, error } = await supabase.from('kategori').insert({ nama_kategori }).select().single();
    if (error) throw error;
    toast('Kategori ditambahkan.', 'success');
    return data;
  } catch (err) {
    toast('Gagal menambah kategori: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function editKategori(id, nama_kategori) {
  setLoading(true);
  try {
    const { error } = await supabase.from('kategori').update({ nama_kategori }).eq('id', id);
    if (error) throw error;
    toast('Kategori diperbarui.', 'success');
  } catch (err) {
    toast('Gagal memperbarui kategori: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function hapusKategori(id) {
  setLoading(true);
  try {
    const { error } = await supabase.from('kategori').delete().eq('id', id);
    if (error) throw error;
    toast('Kategori dihapus.', 'success');
  } catch (err) {
    toast('Gagal menghapus kategori: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}
