// =========================================================
// MODUL ABSENSI MANDIRI PESERTA (termasuk Canvas Tanda Tangan)
// =========================================================
import { supabase } from './supabaseClient.js';
import { STORAGE_BUCKETS } from './config.js';
import { toast, setLoading } from './ui.js';

// ---- Canvas Tanda Tangan ----
export class SignaturePad {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.drawing = false;
    this.hasSignature = false;
    this._resize();
    this._bind();
  }

  _resize() {
    const ratio = window.devicePixelRatio || 1;
    const rect = this.canvas.getBoundingClientRect();
    this.canvas.width = rect.width * ratio;
    this.canvas.height = rect.height * ratio;
    this.ctx.scale(ratio, ratio);
    this.ctx.lineWidth = 2.5;
    this.ctx.lineCap = 'round';
    this.ctx.strokeStyle = '#0F5132';
  }

  _pos(e) {
    const rect = this.canvas.getBoundingClientRect();
    const point = e.touches ? e.touches[0] : e;
    return { x: point.clientX - rect.left, y: point.clientY - rect.top };
  }

  _bind() {
    const start = (e) => {
      e.preventDefault();
      this.drawing = true;
      const { x, y } = this._pos(e);
      this.ctx.beginPath();
      this.ctx.moveTo(x, y);
    };
    const move = (e) => {
      if (!this.drawing) return;
      e.preventDefault();
      const { x, y } = this._pos(e);
      this.ctx.lineTo(x, y);
      this.ctx.stroke();
      this.hasSignature = true;
    };
    const end = () => { this.drawing = false; };

    this.canvas.addEventListener('mousedown', start);
    this.canvas.addEventListener('mousemove', move);
    window.addEventListener('mouseup', end);
    this.canvas.addEventListener('touchstart', start, { passive: false });
    this.canvas.addEventListener('touchmove', move, { passive: false });
    this.canvas.addEventListener('touchend', end);
  }

  clear() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.hasSignature = false;
  }

  isEmpty() {
    return !this.hasSignature;
  }

  toBlob() {
    return new Promise((resolve) => this.canvas.toBlob(resolve, 'image/png'));
  }
}

// ---- Upload tanda tangan ke Supabase Storage ----
async function uploadTandaTangan(blob, kegiatanId) {
  const filename = `${kegiatanId}/${Date.now()}-${crypto.randomUUID()}.png`;
  const { error } = await supabase.storage
    .from(STORAGE_BUCKETS.tandaTangan)
    .upload(filename, blob, { contentType: 'image/png' });
  if (error) throw error;
  const { data } = supabase.storage.from(STORAGE_BUCKETS.tandaTangan).getPublicUrl(filename);
  return data.publicUrl;
}

// ---- Simpan absensi ----
export async function simpanAbsensi(formData, signaturePad, kegiatanId) {
  setLoading(true);
  try {
    let tandaTanganUrl = null;
    if (signaturePad && !signaturePad.isEmpty()) {
      const blob = await signaturePad.toBlob();
      tandaTanganUrl = await uploadTandaTangan(blob, kegiatanId);
    }

    const payload = {
      kegiatan_id: kegiatanId,
      nama_lengkap: formData.nama_lengkap,
      jenis_kelamin: formData.jenis_kelamin,
      status_peserta: formData.status_peserta,
      dapukan: formData.dapukan,
      nomor_whatsapp: formData.nomor_whatsapp,
      alamat: formData.alamat,
      zona_waktu: formData.zona_waktu || 'WIB',
      kehadiran: formData.kehadiran || 'Hadir',
      keterangan: formData.keterangan,
      nominal_infaq: formData.nominal_infaq || 0,
      tanda_tangan_url: tandaTanganUrl,
    };

    const { data, error } = await supabase.from('absensi').insert(payload).select().single();
    if (error) throw error;

    // Catat juga ke tabel infaq jika ada nominal
    if (payload.nominal_infaq > 0) {
      await supabase.from('infaq').insert({
        kegiatan_id: kegiatanId,
        absensi_id: data.id,
        nama_peserta: payload.nama_lengkap,
        nominal: payload.nominal_infaq,
        metode_pembayaran: 'Tunai',
        keterangan: 'Infaq saat absensi',
      });
    }

    toast('Absensi berhasil disimpan. Terima kasih!', 'success');
    return data;
  } catch (err) {
    toast('Gagal menyimpan absensi: ' + err.message, 'error');
    throw err;
  } finally {
    setLoading(false);
  }
}

export async function listAbsensiByKegiatan(kegiatanId) {
  const { data, error } = await supabase
    .from('absensi')
    .select('*')
    .eq('kegiatan_id', kegiatanId)
    .order('waktu_datang', { ascending: true });
  if (error) {
    toast('Gagal memuat data absensi: ' + error.message, 'error');
    return [];
  }
  return data;
}

// Realtime: panggil callback setiap ada perubahan absensi pada kegiatan tsb
export function subscribeAbsensi(kegiatanId, callback) {
  return supabase
    .channel(`absensi-${kegiatanId}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'absensi', filter: `kegiatan_id=eq.${kegiatanId}` }, callback)
    .subscribe();
}
