// =========================================================
// Helper UI: toast notification, loading, format
// =========================================================

export function toast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast toast-${type}`;
  el.textContent = message;
  container.appendChild(el);
  requestAnimationFrame(() => el.classList.add('show'));
  setTimeout(() => {
    el.classList.remove('show');
    setTimeout(() => el.remove(), 300);
  }, duration);
}

export function setLoading(isLoading) {
  document.getElementById('global-loader').classList.toggle('active', isLoading);
}

export function formatTanggalIndo(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  return d.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

export function formatRupiah(num) {
  const n = Number(num || 0);
  return 'Rp ' + n.toLocaleString('id-ID');
}

export function formatJam(dateOrTime) {
  if (!dateOrTime) return '-';
  if (typeof dateOrTime === 'string' && dateOrTime.length <= 8) return dateOrTime.slice(0, 5);
  const d = new Date(dateOrTime);
  return d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
}

export function skeletonCards(count = 3) {
  return Array.from({ length: count })
    .map(() => `<div class="skeleton skeleton-card"></div>`)
    .join('');
}

export function confirmDialog(message) {
  return new Promise((resolve) => {
    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay show';
    overlay.innerHTML = `
      <div class="modal-box">
        <p>${message}</p>
        <div class="modal-actions">
          <button class="btn btn-ghost" data-action="cancel">Batal</button>
          <button class="btn btn-danger" data-action="ok">Ya, Lanjutkan</button>
        </div>
      </div>`;
    document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => {
      const action = e.target.dataset.action;
      if (action) {
        overlay.remove();
        resolve(action === 'ok');
      }
    });
  });
}
