// =========================================================
// KONFIGURASI APLIKASI
// WAJIB DIISI sebelum aplikasi bisa terhubung ke Supabase.
// Ambil nilai ini dari: Supabase Dashboard -> Project Settings -> API
// =========================================================

export const SUPABASE_CONFIG = {
  url: 'https://GANTI-DENGAN-PROJECT-ID.supabase.co',
  anonKey: 'GANTI-DENGAN-ANON-PUBLIC-KEY',
};

// Nama bucket storage (harus sama persis dengan yang dibuat di 02_rls.sql)
export const STORAGE_BUCKETS = {
  logo: 'logo',
  stempel: 'stempel',
  tandaTangan: 'tanda-tangan',
  banner: 'banner',
  laporan: 'laporan',
};

// Base URL aplikasi ini setelah di-deploy (dipakai untuk membuat link absensi & QR).
// Contoh: 'https://pengajian.majelis-anda.com'
export const APP_BASE_URL = window.location.origin + window.location.pathname;

export const DEFAULT_THEME = {
  primary: '#0F5132',   // emerald green
  accent: '#D4AF37',    // gold
  surface: '#FFFFFF',
  surfaceMuted: '#F3F5F4',
};
