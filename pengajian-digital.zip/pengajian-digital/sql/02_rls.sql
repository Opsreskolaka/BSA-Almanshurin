-- =========================================================
-- ROW LEVEL SECURITY
-- Jalankan setelah 01_schema.sql
-- =========================================================

alter table public.users enable row level security;
alter table public.organisasi enable row level security;
alter table public.kategori enable row level security;
alter table public.kegiatan enable row level security;
alter table public.peserta enable row level security;
alter table public.absensi enable row level security;
alter table public.infaq enable row level security;
alter table public.tanda_tangan enable row level security;
alter table public.banner enable row level security;
alter table public.laporan enable row level security;

-- Helper: role user yang sedang login
create or replace function public.current_role_is(roles text[])
returns boolean as $$
  select exists (
    select 1 from public.users u
    where u.id = auth.uid() and u.role = any(roles)
  );
$$ language sql stable security definer;

-- ---------------------------------------------------------
-- USERS
-- ---------------------------------------------------------
create policy "users_select_own_or_admin" on public.users
  for select using (
    id = auth.uid() or public.current_role_is(array['super_admin','admin'])
  );

create policy "users_update_own_or_admin" on public.users
  for update using (
    id = auth.uid() or public.current_role_is(array['super_admin','admin'])
  );

create policy "users_insert_admin" on public.users
  for insert with check (
    id = auth.uid() or public.current_role_is(array['super_admin','admin'])
  );

-- ---------------------------------------------------------
-- ORGANISASI: semua orang login boleh baca, hanya admin boleh ubah
-- ---------------------------------------------------------
create policy "organisasi_select_all" on public.organisasi
  for select using (auth.role() = 'authenticated');

create policy "organisasi_write_admin" on public.organisasi
  for all using (public.current_role_is(array['super_admin','admin']))
  with check (public.current_role_is(array['super_admin','admin']));

-- ---------------------------------------------------------
-- KATEGORI: baca publik (untuk halaman absensi tanpa login),
-- tulis hanya admin
-- ---------------------------------------------------------
create policy "kategori_select_public" on public.kategori
  for select using (true);

create policy "kategori_write_admin" on public.kategori
  for all using (public.current_role_is(array['super_admin','admin']))
  with check (public.current_role_is(array['super_admin','admin']));

-- ---------------------------------------------------------
-- KEGIATAN: baca publik (peserta scan QR tanpa login),
-- tulis oleh admin & penanggung jawab
-- ---------------------------------------------------------
create policy "kegiatan_select_public" on public.kegiatan
  for select using (true);

create policy "kegiatan_write_admin" on public.kegiatan
  for all using (public.current_role_is(array['super_admin','admin','penanggung_jawab']))
  with check (public.current_role_is(array['super_admin','admin','penanggung_jawab']));

-- ---------------------------------------------------------
-- PESERTA: baca oleh user login, tulis oleh admin
-- ---------------------------------------------------------
create policy "peserta_select_authenticated" on public.peserta
  for select using (auth.role() = 'authenticated');

create policy "peserta_write_admin" on public.peserta
  for all using (public.current_role_is(array['super_admin','admin']))
  with check (public.current_role_is(array['super_admin','admin']));

-- ---------------------------------------------------------
-- ABSENSI: insert publik (peserta mengisi absensi mandiri via QR,
-- tanpa login), select/update/delete hanya staf
-- ---------------------------------------------------------
create policy "absensi_insert_public" on public.absensi
  for insert with check (true);

create policy "absensi_select_staff" on public.absensi
  for select using (
    auth.role() = 'authenticated'
    or public.current_role_is(array['super_admin','admin','penanggung_jawab'])
  );

create policy "absensi_update_staff" on public.absensi
  for update using (public.current_role_is(array['super_admin','admin','penanggung_jawab']));

create policy "absensi_delete_staff" on public.absensi
  for delete using (public.current_role_is(array['super_admin','admin']));

-- ---------------------------------------------------------
-- INFAQ: insert oleh staf/peserta (via absensi), baca oleh staf
-- ---------------------------------------------------------
create policy "infaq_insert_any" on public.infaq
  for insert with check (true);

create policy "infaq_select_staff" on public.infaq
  for select using (
    auth.role() = 'authenticated'
    or public.current_role_is(array['super_admin','admin','penanggung_jawab'])
  );

create policy "infaq_write_admin" on public.infaq
  for update using (public.current_role_is(array['super_admin','admin']));

create policy "infaq_delete_admin" on public.infaq
  for delete using (public.current_role_is(array['super_admin','admin']));

-- ---------------------------------------------------------
-- TANDA_TANGAN
-- ---------------------------------------------------------
create policy "ttd_insert_public" on public.tanda_tangan
  for insert with check (true);

create policy "ttd_select_staff" on public.tanda_tangan
  for select using (
    auth.role() = 'authenticated'
    or public.current_role_is(array['super_admin','admin','penanggung_jawab'])
  );

-- ---------------------------------------------------------
-- BANNER & LAPORAN: hanya staf
-- ---------------------------------------------------------
create policy "banner_all_staff" on public.banner
  for all using (public.current_role_is(array['super_admin','admin','penanggung_jawab']))
  with check (public.current_role_is(array['super_admin','admin','penanggung_jawab']));

create policy "laporan_all_staff" on public.laporan
  for all using (public.current_role_is(array['super_admin','admin','penanggung_jawab']))
  with check (public.current_role_is(array['super_admin','admin','penanggung_jawab']));

-- ---------------------------------------------------------
-- STORAGE BUCKETS (jalankan di SQL editor atau buat manual di dashboard)
-- ---------------------------------------------------------
insert into storage.buckets (id, name, public)
values
  ('logo', 'logo', true),
  ('stempel', 'stempel', true),
  ('tanda-tangan', 'tanda-tangan', true),
  ('banner', 'banner', true),
  ('laporan', 'laporan', false)
on conflict (id) do nothing;

create policy "logo_public_read" on storage.objects
  for select using (bucket_id in ('logo','stempel','tanda-tangan','banner'));

create policy "logo_admin_write" on storage.objects
  for insert with check (bucket_id in ('logo','stempel','banner','laporan'));

create policy "ttd_public_write" on storage.objects
  for insert with check (bucket_id = 'tanda-tangan');
