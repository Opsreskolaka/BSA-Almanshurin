-- =========================================================
-- SEED DATA
-- Jalankan setelah 01_schema.sql dan 02_rls.sql
-- =========================================================

-- Identitas organisasi default (satu baris)
insert into public.organisasi (nama_organisasi, nama_masjid, nama_kelompok, nama_aplikasi, footer_text, warna_primer, warna_aksen)
values (
  'Majelis Al-Ikhlas',
  'Masjid Al-Ikhlas',
  'Kelompok Al-Ikhlas',
  'Sistem Daftar Hadir Pengajian',
  'Majelis Al-Ikhlas • Modern, Mudah, Amanah',
  '#0F5132',
  '#D4AF37'
)
on conflict do nothing;

-- Kategori bawaan
insert into public.kategori (nama_kategori, urutan) values
  ('Ngaji Kelompok', 1),
  ('Pengajian Ibu-Ibu', 2),
  ('Pengajian Muda-Mudi', 3),
  ('Pengajian Turba Kelompok', 4)
on conflict do nothing;

-- CATATAN PENTING SOAL USER / AUTH
-- -----------------------------------
-- Supabase Auth mengelola akun (email/password) di tabel auth.users,
-- yang TIDAK bisa diisi lewat SQL seed biasa. Untuk membuat akun
-- Super Admin pertama:
--
-- 1) Buka Supabase Dashboard -> Authentication -> Users -> Add User
--    Buat user dengan email & password admin Anda.
-- 2) Salin User UID yang muncul, lalu jalankan query berikut
--    (ganti UUID_DARI_DASHBOARD dan email sesuai):
--
-- insert into public.users (id, nama_lengkap, username, email, role)
-- values ('UUID_DARI_DASHBOARD', 'Super Admin', 'admin', 'admin@majelis.local', 'super_admin');
--
-- Ulangi langkah ini untuk setiap admin / penanggung jawab tambahan,
-- cukup ganti role menjadi 'admin' atau 'penanggung_jawab'.
