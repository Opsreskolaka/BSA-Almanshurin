-- =========================================================
-- SKEMA DATABASE: Daftar Hadir Pengajian Digital
-- Jalankan file ini di Supabase SQL Editor (urutan: 01, 02, 03)
-- =========================================================

create extension if not exists "uuid-ossp";

-- ---------------------------------------------------------
-- USERS (profil tambahan di atas auth.users bawaan Supabase)
-- ---------------------------------------------------------
create table if not exists public.users (
  id uuid primary key references auth.users(id) on delete cascade,
  nama_lengkap text not null,
  username text unique,
  email text unique,
  role text not null default 'peserta'
    check (role in ('super_admin','admin','penanggung_jawab','peserta')),
  nomor_whatsapp text,
  avatar_url text,
  aktif boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- ORGANISASI (identitas & branding, biasanya 1 baris saja)
-- ---------------------------------------------------------
create table if not exists public.organisasi (
  id uuid primary key default uuid_generate_v4(),
  nama_organisasi text not null default 'Majelis Al-Ikhlas',
  nama_masjid text,
  nama_kelompok text,
  nama_aplikasi text not null default 'Daftar Hadir Pengajian Digital',
  footer_text text,
  logo_url text,
  lambang_url text,
  stempel_url text,
  warna_primer text not null default '#0F5132',
  warna_aksen text not null default '#D4AF37',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- KATEGORI PENGAJIAN
-- ---------------------------------------------------------
create table if not exists public.kategori (
  id uuid primary key default uuid_generate_v4(),
  nama_kategori text not null,
  deskripsi text,
  urutan int default 0,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- KEGIATAN
-- ---------------------------------------------------------
create table if not exists public.kegiatan (
  id uuid primary key default uuid_generate_v4(),
  nama_kegiatan text not null,
  kategori_id uuid references public.kategori(id) on delete set null,
  tema text,
  hari text,
  tanggal date not null,
  jam_mulai time not null,
  jam_selesai time,
  tempat text,
  pemateri text,
  penanggung_jawab text,
  dapukan_penanggung_jawab text,
  nomor_whatsapp_pj text,
  catatan text,
  status text not null default 'draft'
    check (status in ('draft','aktif','selesai')),
  token_absensi text not null default encode(gen_random_bytes(12), 'hex'),
  waktu_mulai_absen timestamptz,
  waktu_selesai_absen timestamptz,
  dibuat_oleh uuid references public.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists idx_kegiatan_status on public.kegiatan(status);
create index if not exists idx_kegiatan_tanggal on public.kegiatan(tanggal);

-- ---------------------------------------------------------
-- PESERTA (master data peserta, opsional dipakai untuk kartu anggota)
-- ---------------------------------------------------------
create table if not exists public.peserta (
  id uuid primary key default uuid_generate_v4(),
  nama_lengkap text not null,
  jenis_kelamin text check (jenis_kelamin in ('Pria','Wanita')),
  status_peserta text,
  dapukan text,
  nomor_whatsapp text,
  alamat text,
  foto_url text,
  nomor_anggota text unique,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- ABSENSI (satu baris = satu kehadiran pada satu kegiatan)
-- ---------------------------------------------------------
create table if not exists public.absensi (
  id uuid primary key default uuid_generate_v4(),
  kegiatan_id uuid not null references public.kegiatan(id) on delete cascade,
  peserta_id uuid references public.peserta(id) on delete set null,
  nama_lengkap text not null,
  jenis_kelamin text check (jenis_kelamin in ('Pria','Wanita')),
  status_peserta text,
  dapukan text,
  nomor_whatsapp text,
  alamat text,
  waktu_datang timestamptz not null default now(),
  zona_waktu text default 'WIB' check (zona_waktu in ('WIB','WITA','WIT')),
  kehadiran text not null default 'Hadir'
    check (kehadiran in ('Hadir','Izin/Berhalangan','Sakit','Alfa')),
  keterangan text,
  nominal_infaq numeric(12,2) default 0,
  tanda_tangan_url text,
  created_at timestamptz not null default now()
);

create index if not exists idx_absensi_kegiatan on public.absensi(kegiatan_id);

-- ---------------------------------------------------------
-- INFAQ (transaksi infaq, bisa berdiri sendiri atau terhubung absensi)
-- ---------------------------------------------------------
create table if not exists public.infaq (
  id uuid primary key default uuid_generate_v4(),
  kegiatan_id uuid references public.kegiatan(id) on delete set null,
  absensi_id uuid references public.absensi(id) on delete set null,
  nama_peserta text not null,
  nominal numeric(12,2) not null default 0,
  metode_pembayaran text check (metode_pembayaran in ('Tunai','Transfer','QRIS','Lainnya')),
  keterangan text,
  created_at timestamptz not null default now()
);

create index if not exists idx_infaq_kegiatan on public.infaq(kegiatan_id);
create index if not exists idx_infaq_created on public.infaq(created_at);

-- ---------------------------------------------------------
-- TANDA_TANGAN (arsip file tanda tangan, jika disimpan terpisah dari absensi)
-- ---------------------------------------------------------
create table if not exists public.tanda_tangan (
  id uuid primary key default uuid_generate_v4(),
  absensi_id uuid references public.absensi(id) on delete cascade,
  file_url text not null,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- BANNER (banner/spanduk yang digenerate untuk tiap kegiatan)
-- ---------------------------------------------------------
create table if not exists public.banner (
  id uuid primary key default uuid_generate_v4(),
  kegiatan_id uuid references public.kegiatan(id) on delete cascade,
  file_url text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- LAPORAN (log export laporan: siapa export, format apa, kapan)
-- ---------------------------------------------------------
create table if not exists public.laporan (
  id uuid primary key default uuid_generate_v4(),
  kegiatan_id uuid references public.kegiatan(id) on delete set null,
  format text check (format in ('PDF','Word','Excel','TXT')),
  dibuat_oleh uuid references public.users(id),
  file_url text,
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- Trigger updated_at generik
-- ---------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

drop trigger if exists trg_users_updated on public.users;
create trigger trg_users_updated before update on public.users
  for each row execute function public.set_updated_at();

drop trigger if exists trg_organisasi_updated on public.organisasi;
create trigger trg_organisasi_updated before update on public.organisasi
  for each row execute function public.set_updated_at();

drop trigger if exists trg_kegiatan_updated on public.kegiatan;
create trigger trg_kegiatan_updated before update on public.kegiatan
  for each row execute function public.set_updated_at();

-- Aktifkan Realtime pada tabel yang perlu live-update
alter publication supabase_realtime add table public.absensi;
alter publication supabase_realtime add table public.infaq;
alter publication supabase_realtime add table public.kegiatan;
