# Dokumentasi Deploy

Aplikasi ini adalah file statis (HTML/CSS/JS) + backend Supabase, jadi bisa
di-deploy ke hosting statis mana pun. Berikut opsi paling praktis:

## Opsi A — Netlify (drag & drop, gratis)
1. Buka https://app.netlify.com/drop
2. Seret seluruh folder project (yang berisi `index.html`) ke halaman tersebut.
3. Netlify akan memberi URL publik otomatis, mis. `https://nama-anda.netlify.app`.
4. Update `js/config.js` jika perlu, lalu re-deploy.

## Opsi B — Vercel
1. `npm i -g vercel`
2. Di folder project: `vercel --prod`
3. Ikuti instruksi CLI.

## Opsi C — GitHub Pages
1. Push folder project ke repository GitHub.
2. Settings → Pages → pilih branch `main` dan folder root.
3. URL akan aktif di `https://username.github.io/nama-repo/`.

## Opsi D — Hosting Supabase Storage (statis sederhana)
Bisa juga meng-host file statis di bucket Storage public, meski opsi A–C lebih umum untuk SPA.

## Setelah Deploy
- Pastikan `APP_BASE_URL` di `js/config.js` (dihitung otomatis dari `window.location`)
  sudah sesuai domain final — link absensi & QR Code memakai nilai ini.
- Di Supabase Dashboard → Authentication → URL Configuration, tambahkan domain
  hasil deploy ke **Site URL** dan **Redirect URLs** agar reset password &
  login Google berjalan normal.
- Uji buka `https://domain-anda.com/index.html?event=ID_KEGIATAN` dari HP lain
  untuk memastikan absensi mandiri via QR berfungsi tanpa login.
