# Dokumentasi Instalasi — Daftar Hadir Pengajian Digital

## 1. Buat Project Supabase
1. Buka https://supabase.com → **New Project**.
2. Catat **Project URL** dan **anon public key** (Project Settings → API).

## 2. Jalankan Skema Database
Buka **SQL Editor** di dashboard Supabase, lalu jalankan berurutan:
1. `sql/01_schema.sql` — membuat semua tabel.
2. `sql/02_rls.sql` — mengaktifkan Row Level Security & membuat bucket storage.
3. `sql/03_seed.sql` — mengisi data awal (organisasi & kategori bawaan).

## 3. Buat Akun Super Admin
Supabase Auth tidak bisa diisi lewat SQL biasa:
1. Dashboard → **Authentication → Users → Add User**. Isi email & password.
2. Salin **User UID** yang muncul.
3. Jalankan di SQL Editor:
   ```sql
   insert into public.users (id, nama_lengkap, username, email, role)
   values ('UUID_HASIL_COPY', 'Super Admin', 'admin', 'admin@email-anda.com', 'super_admin');
   ```

## 4. Isi Konfigurasi Aplikasi
Buka `js/config.js`, isi:
```js
export const SUPABASE_CONFIG = {
  url: 'https://xxxxxxxx.supabase.co',
  anonKey: 'eyJhbGciOi...',
};
```

## 5. Jalankan Secara Lokal
Karena aplikasi memakai ES Module, buka lewat server lokal (bukan `file://`):
```bash
# opsi 1: Python
python3 -m http.server 8080

# opsi 2: Node (http-server)
npx http-server -p 8080
```
Lalu buka `http://localhost:8080` di browser.

## 6. Login Pertama Kali
Gunakan email & password Super Admin yang dibuat di langkah 3.

## 7. Catatan Fitur WhatsApp
Aplikasi memakai link **wa.me** (klik-untuk-chat) sehingga tidak perlu API berbayar,
namun pengiriman tetap perlu menekan tombol kirim secara manual di WhatsApp.
Untuk pengiriman **otomatis massal** tanpa interaksi manual, Anda perlu
mendaftar ke provider WhatsApp Business API (mis. Fonnte, Wablas, atau Twilio)
dan mengisi kredensialnya di `js/whatsapp.js` pada fungsi `kirimViaProviderAPI()`.
